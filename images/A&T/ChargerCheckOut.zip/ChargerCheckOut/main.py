import tkinter.messagebox
from tkinter import *
from fpdf import FPDF
import datetime

# #E6E6E6 whitish
# #FAD662 yellowish
# #E57B5C orangish
# #BE4747 redish
log_location = "log.txt"
data_location = "data.txt"
output_location = r'C:\Users\alexc\Desktop\test\logs.pdf'

pdf = FPDF()
checked_out = dict()
font = ("Helvetica", 9)

window = Tk()
window.minsize(width=400, height=400)
window.title('Charger Checkout')
window.config(pady=20, background="#E6E6E6")
window.iconbitmap("RUHS_logo_new.ico")
window.resizable(False, False)


class Checkouts:

    def __init__(self, to):
        if to != "first":
            self.clear_all()
        self.add_all()

    def clear_all(self):
        global checked_out
        for thing in checked_out:
            checked_out[thing].destroy()
            checked_out[thing].destroy()

    def add_all(self):
        global checked_out
        for name in current_list:
            mult = current_list.index(name) + 1
            if mult < 21 and mult % 2 != 0:
                checked_out[f"{name}1"] = Label(text=name, background="#E6E6E6", font=font)
                checked_out[f"{name}2"] = Button(text="-", command=lambda id=name: remove_student(id), bg="#E25E3E",
                                                 fg="black", font=font)
                checked_out[f"{name}2"].config(width=2)
                checked_out[f"{name}1"].place(x=70, y=((mult + 1) / 2 * 32) - 32)
                checked_out[f"{name}2"].place(x=40, y=((mult + 1) / 2 * 32) - 32)
            elif mult < 21 and mult % 2 == 0:
                checked_out[f"{name}1"] = Label(text=name, background="#E6E6E6", font=font)
                checked_out[f"{name}2"] = Button(text="-", command=lambda id=name: remove_student(id), bg="#E25E3E",
                                                 fg="black", font=font)
                checked_out[f"{name}2"].config(width=2)
                checked_out[f"{name}1"].place(x=260, y=((mult / 2) * 32) - 32)
                checked_out[f"{name}2"].place(x=230, y=((mult / 2) * 32) - 32)
            else:
                print("Maximum limit reached")


def remove_student(id):
    date = datetime.datetime.now()
    data = open(data_location, "w")
    with open(log_location, "a") as logs:
        checked_out[f"{id}1"].destroy()
        checked_out[f"{id}2"].destroy()
        current_list.remove(id)
        logs.write(f"{id.title()} Checked charger in on {date.strftime('%B %d %Y at %I:%M %p')}\n")
        for info in current_list:
            data.write(f"{info}\n")
    Checkouts("fianl")


def add_student():
    date = datetime.datetime.now()
    student = name_input.get().title()
    data = open(data_location, "w")
    if not student.isspace():
        if student in current_list:
            tkinter.messagebox.showinfo('Alert', 'This Person is Already Checked Out')
        else:
            if not len(current_list) > 19:
                with open(log_location, "a") as logs:
                    logs.write(f"{student.title()} Checked charger out on {date.strftime('%B %d %Y at %I:%M %p')}\n")
                current_list.append(student)
                test = Checkouts("last")
            else:
                tkinter.messagebox.showinfo('Alert', 'Maximum Limit for Checkouts Reached')
            for info in current_list:
                data.write(f"{info}\n")
    name_input.delete(0, "end")


def see_logs():
    with open(log_location, "r") as loging:
        pdf.add_page()
        pdf.set_font("Helvetica", size=25, style="B")
        pdf.cell(200, 10, txt="Chromebook Charger Checkout Log", ln=1, align="C")
        pdf.set_font("Helvetica", size=14)
        for line in loging:
            pdf.cell(200, 10, txt=line, ln=1, align='C')
        pdf.output(output_location)
        # logs = loging.read().split("\n")
        # info = [log  for log in logs if logs.index(log) > len(logs) - 23]
        # tkinter.messagebox.showinfo('Alert', f"{info}")


data = open(data_location, "r")
current_list = data.read().split("\n")
for item in current_list:
    if item == "":
        current_list.remove(item)
test = Checkouts("first")

name_input = Entry(width=15)
name_input.config(width=25)
name_input.place(x=28, y=352.5)

add_button = Button(text="Add Student", command=add_student, font=font)
add_button.config(width=15, background="#FAD662")
add_button.place(x=185, y=350)

logs_button = Button(text="Logs", command=see_logs, font=font)
logs_button.config(width=5, height=2, background="#FAD662")
logs_button.place(x=320, y=320)

window.mainloop()
